var validar = function(){
    var nombres = document.formulario.nombres1;//getElementById
    if(nombres.value == ""){
        document.getElementById("mensaje_nombres").innerText = "El campo nombres es requerido";
    }else if(nombres.value.length<3){
        document.getElementsById("mensaje_nombres").innerText="El campo debe tener como minimo tres caracteres";

    }else if(!nombres.value.match(/^[a-z]+$/i)){
        document.getElementsById("mensaje_nombres").innerText="El campo solo acepta letras";
    }else{
        document.getElementsById("mensaje_nombres").innerText=" ";
    }
}

window.onload = function(){
    var boton = document.getElementsById("btn_validar");
    boton.onclick = function(){
        validar();
    }
}